Aria.classDefinition({
    $classpath : "exercises.handson.core.Logger",
    $singleton : true,
    $prototype : {
        debug : function (message) {
            console.debug(message);
        },

        info : function (message) {
            console.info(message);
        }
    }
});