Aria.classDefinition({
    $classpath : "exercises.handson.core.Square",
    $extends : "exercises.handson.core.Rectangle",
    $constructor : function (color, width) {
        this.$Rectangle.constructor.apply(this, [color, width, width]);
    },
    $statics : {
        DEFAULT_WIDTH : 3
    },
    $prototype : {}
});