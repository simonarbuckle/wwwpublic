Aria.classDefinition({
    $classpath : "exercises.handson.core.Logger",
    $singleton : true,
    $prototype : {
        debug : function (message) {
            this.$logDebug(message);
        },

        info : function (message) {
            this.$logInfo(message);
        }
    }
});