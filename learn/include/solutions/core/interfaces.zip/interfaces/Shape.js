Aria.classDefinition({
    $classpath : "exercises.handson.core.Shape",
    $dependencies : ["exercises.handson.core.Logger", "exercises.handson.core.ShapeDefinitions"],
    $implements : ["exercises.handson.core.IShape"],
    $constructor : function (color) {
        this._color = color || this.DEFAULT_COLOR;
        exercises.handson.core.Logger.debug("Creation of a " + this._color + " shape");
    },
    $statics : {
        DEFAULT_COLOR : "black"
    },
    $prototype : {

        getColor : function () {
            return this._color;
        }

    }
});