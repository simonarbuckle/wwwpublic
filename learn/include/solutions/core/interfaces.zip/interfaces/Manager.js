Aria.classDefinition({
    $classpath : "exercises.handson.core.Manager",
    $singleton : true,
    $dependencies : ["aria.utils.Json"],
    $constructor : function () {
        this.__shapes = [];
    },
    $events : {
        "shapeAdded" : {
            description : "Raised when a shape is added to the store"
        },
        "shapeRemoved" : "Raised when a shape get removed from the store"
    },
    $prototype : {

        addShape : function (shape) {
            this.__shapes.push(shape);
            this.$raiseEvent("shapeAdded");
            return this.__shapes.length - 1;
        },

        removeShape : function (index) {
            if (index < this.__shapes.length) {
                aria.utils.Json.removeAt(this.__shapes, index);
                this.$raiseEvent("shapeRemoved");
            }
        },

        getShape : function (index) {
            if (index < this.__shapes.length) {
                return this.__shapes[index].$interface("exercises.handson.core.IShape");
            }
            return null;
        }
    }
});