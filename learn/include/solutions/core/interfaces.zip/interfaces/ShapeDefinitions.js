Aria.beanDefinitions({
    $package : "exercises.handson.core.ShapeDefinitions",
    $namespaces : {
        "json" : "aria.core.JsonTypes"
    },
    $beans : {
        "SquareConfiguration" : {
            $type : "json:Object",
            $properties : {
                "color" : {
                    $type : "json:Enum",
                    $description : "Color used to fill the shape",
                    $enumValues : ["red", "green", "blue", "#1A61A9"],
                    $default : "red"
                },
                "width" : {
                    $type : "json:Integer",
                    $description : "Size of the sides of the square"
                }
            }
        }
    }
});