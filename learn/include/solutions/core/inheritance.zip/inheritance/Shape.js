Aria.classDefinition({
    $classpath : "exercises.handson.core.Shape",
    $constructor : function (color) {
        this._color = color || this.DEFAULT_COLOR;
    },
    $statics : {
        DEFAULT_COLOR : "black"
    },
    $prototype : {

        getColor : function () {
            return this._color;
        }

    }
});