Aria.classDefinition({
    $classpath : "exercises.handson.core.Rectangle",
    $extends : "exercises.handson.core.Shape",
    $constructor : function (color, width, height) {
        this.$Shape.constructor.call(this, color);
        this._width = width || this.DEFAULT_WIDTH;
        this._height = height || this.DEFAULT_HEIGHT;
    },
    $statics : {
        DEFAULT_COLOR : "blue",
        DEFAULT_WIDTH : 5,
        DEFAULT_HEIGHT : 3
    },
    $prototype : {

        computeArea : function () {
            return this._width * this._height;
        }
    }
});