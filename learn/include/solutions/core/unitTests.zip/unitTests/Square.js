Aria.classDefinition({
    $classpath : "exercises.handson.core.Square",
    $extends : "exercises.handson.core.Rectangle",
    $dependencies : ["exercises.handson.core.ShapeDefinitions", "aria.core.JsonValidator"],
    $constructor : function (conf) {
        conf = conf || {};
        aria.core.JsonValidator.normalize({
            json : conf,
            beanName : 'exercises.handson.core.ShapeDefinitions.SquareConfiguration'
        });

        this.$Rectangle.constructor.apply(this, [conf.color, conf.width, conf.width]);
    },
    $statics : {
        DEFAULT_WIDTH : 3
    },
    $prototype : {}
});