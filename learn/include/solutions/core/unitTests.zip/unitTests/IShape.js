Aria.interfaceDefinition({
    $classpath : "exercises.handson.core.IShape",
    $interface : {

        getColor : {
            $type : "Function"
        }
    }
});