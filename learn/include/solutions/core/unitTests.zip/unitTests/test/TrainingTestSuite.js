Aria.classDefinition({
    $classpath : "exercises.handson.core.test.TrainingTestSuite",
    $extends : "aria.jsunit.TestSuite",
    $constructor : function () {
        this.$TestSuite.constructor.call(this);
        this.addTests("exercises.handson.core.test.SquareTest");
    }
});