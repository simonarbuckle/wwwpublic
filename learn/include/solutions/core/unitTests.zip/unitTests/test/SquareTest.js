Aria.classDefinition({
    $classpath : "exercises.handson.core.test.SquareTest",
    $extends : "aria.jsunit.TestCase",
    $dependencies : ["exercises.handson.core.Square"],
    $prototype : {

        testGetColor : function () {

            // We create a new Square
            var square = new exercises.handson.core.Square();

            this.assertEquals(square.getColor(), "red", "When no argument is specified for the Square constructor, it should default to red.");

            // We destroy the instance
            square.$dispose();
        },

        testComputeArea : function () {

            // We create a new Square
            var square = new exercises.handson.core.Square({
                width : 2
            });

            this.assertEquals(square.computeArea(), 4, "The area of the square should be equal to 4.");

            // We destroy the instance
            square.$dispose();
        }
    }
});