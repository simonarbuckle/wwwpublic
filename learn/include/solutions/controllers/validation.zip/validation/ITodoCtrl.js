Aria.interfaceDefinition({
    $classpath : "exercises.handson.todoctrl.ITodoCtrl",
    $extends : "aria.templates.IModuleCtrl",

    $interface : {

        deleteTask : {
            $type : "Function"
        },

        addTask : {
            $type : "Function"
        }

    }
});
