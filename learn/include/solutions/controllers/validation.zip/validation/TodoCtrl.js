Aria.classDefinition({
    $classpath : "exercises.handson.todoctrl.TodoCtrl",
    $extends : "aria.templates.ModuleCtrl",
    $implements : ["exercises.handson.todoctrl.ITodoCtrl"],
    $statics : {
        INVALID_NEW_TASK_LABEL : "The label for the new task is not valid. It should be have between 1 and 20 characters"
    },
    $constructor : function () {
        this.$ModuleCtrl.constructor.call(this);
    },
    $prototype : {

        $publicInterfaceName : "exercises.handson.todoctrl.ITodoCtrl",

        init : function (args, cb) {
            this._data = {
                tasksList : [{
                            label : "Buy bread",
                            done : false
                        }, {
                            label : "Pick up Jack",
                            done : false
                        }, {
                            label : "Call Jane",
                            done : true
                        }],
                newTask : "",
                error : ""
            };
            this.$callback(cb);
        },

        deleteTask : function (e, task) {
            var idx = this._data.tasksList.indexOf(task);
            this.json.removeAt(this._data.tasksList, idx);
        },

        addTask : function () {
            this.json.setValue(this._data, "error", "");
            var newTask = this._data.newTask;
            var valid = this._validateTaskLabel(newTask);
            if (valid) {
                this.json.add(this._data.tasksList, {
                    label : newTask,
                    done : false
                });
            } else {
                this.json.setValue(this._data, "error", this.INVALID_NEW_TASK_LABEL);
            }
        },

        _validateTaskLabel : function (label) {
            var labelLength = label.length;
            return (labelLength > 0) && (labelLength <= 20);
        }

    }
});
