Aria.classDefinition({
    $classpath : "exercises.handson.todoctrl.TodoCtrl",
    $extends : "aria.templates.ModuleCtrl",
    $implements : ["exercises.handson.todoctrl.ITodoCtrl"],
    $statics : {
        INVALID_NEW_TASK_LABEL : "The label for the new task is not valid. It should be have between 1 and 20 characters"
    },
    $constructor : function () {
        this.$ModuleCtrl.constructor.call(this);
    },
    $prototype : {

        $publicInterfaceName : "exercises.handson.todoctrl.ITodoCtrl",

        init : function (args, cb) {
            this._data = {
                newTask : "",
                error : ""
            };

            aria.core.IO.asyncRequest({
                url : "/myServer/getTasks",
                expectedResponseType : "json",
                callback : {
                    fn : this._onTaskReceive,
                    scope : this,
                    args : cb
                }
            });
        },

        _onTaskReceive : function (res, cb) {
            this._data.tasksList = res.responseJSON.tasksList;
            this.$callback(cb);
        },

        deleteTask : function (e, task) {
            var idx = this._data.tasksList.indexOf(task);
            this.json.removeAt(this._data.tasksList, idx);
        },

        addTask : function (e, cb) {
            this.json.setValue(this._data, "error", "");
            var newTask = this._data.newTask;
            var valid = this._validateTaskLabel(newTask);
            if (valid) {
                aria.core.IO.asyncRequest({
                    url : "/myServer/addTask",
                    expectedResponseType : "json",
                    callback : {
                        fn : this._onTaskAdd,
                        scope : this,
                        args : cb
                    }
                });

            } else {
                this.json.setValue(this._data, "error", this.INVALID_NEW_TASK_LABEL);
                this.$callback(cb);
            }
        },

        _onTaskAdd : function (res, cb) {
            var response = res.responseJSON;
            if (response.error) {
                this.json.setValue(this._data, "error", response.msg);
            } else {
                this.json.add(this._data.tasksList, {
                    label : this._data.newTask,
                    done : false
                });
            }
            this.$callback(cb);
        },

        _validateTaskLabel : function (label) {
            var labelLength = label.length;
            return (labelLength > 0) && (labelLength <= 20);
        }

    }
});
