Aria.tplScriptDefinition({
    $classpath : "exercises.handson.todoctrl.view.TodoScript",
    $prototype : {}
});
