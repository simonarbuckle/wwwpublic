Aria.classDefinition({
    $classpath : "exercises.handson.todoctrl.mocks.Ghost",
    $extends : "aria.core.IOFilter",
    $constructor : function () {
        this.$IOFilter.constructor.call(this);
    },

    $prototype : {

        onRequest : function (req) {
            var responseFile = null;

            if (req.url.match(/getTasks/) !== null) {
                req.delay = 2000;
                responseFile = "tasks";
            }

            if (req.url.match(/addTask/) !== null) {
                req.delay = 2000;
                var randomNumber = Math.round(Math.random());
                responseFile = randomNumber ? "addTaskOk" : "addTaskKo";
            }

            if (responseFile) {
                this.redirectToFile(req, "exercises/handson/todoctrl/mocks/" + responseFile + ".json");
            }
        }

    }
});
