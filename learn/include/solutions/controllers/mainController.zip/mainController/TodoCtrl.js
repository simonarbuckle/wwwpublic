Aria.classDefinition({
    $classpath : "exercises.handson.todoctrl.TodoCtrl",
    $extends : "aria.templates.ModuleCtrl",
    $implements : ["exercises.handson.todoctrl.ITodoCtrl"],

    $constructor : function () {
        this.$ModuleCtrl.constructor.call(this);
    },

    $prototype : {

        $publicInterfaceName : "exercises.handson.todoctrl.ITodoCtrl",

        init : function (args, cb) {
            this._data = {
                tasksList : [{
                            label : "Buy bread",
                            done : false
                        }, {
                            label : "Pick up Jack",
                            done : false
                        }, {
                            label : "Call Jane",
                            done : true
                        }],
                newTask : ""
            };
            this.$callback(cb);
        },

        deleteTask : function (e, task) {
            var idx = this._data.tasksList.indexOf(task);
            this.json.removeAt(this._data.tasksList, idx);
        },

        addTask : function () {
            this.json.add(this._data.tasksList, {
                label : this._data.newTask,
                done : false
            });
        }

    }
});
