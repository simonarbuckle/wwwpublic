Aria.tplScriptDefinition({
    $classpath : "exercises.handson.todoctrl.view.NewTaskScript",
    $prototype : {
        onModuleEvent : function (event) {
            if (event.name == "listUpdated") {
                this.$json.setValue(this.viewData, "processing", false);
            }
        },

        addTask : function () {
            this.$json.setValue(this.viewData, "processing", true);
            this.moduleCtrl.addTask();
        }
    }
});
