Aria.tplScriptDefinition({
    $classpath : "exercises.handson.todoctrl.view.TodoScript",
    $prototype : {
        onModuleEvent : function (event) {
            if (event.name == "listUpdateBegin") {
                this.$json.setValue(this.viewData, "processing", true);
            }
            if (event.name == "listUpdated") {
                this.$json.setValue(this.viewData, "processing", false);
            }
        }
    }
});
