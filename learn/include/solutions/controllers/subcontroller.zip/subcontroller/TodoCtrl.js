Aria.classDefinition({
    $classpath : "exercises.handson.todoctrl.TodoCtrl",
    $extends : "aria.templates.ModuleCtrl",
    $implements : ["exercises.handson.todoctrl.ITodoCtrl"],
    $prototype : {

        $publicInterfaceName : "exercises.handson.todoctrl.ITodoCtrl",

        init : function (args, cb) {

            aria.core.IO.asyncRequest({
                url : "/myServer/getTasks",
                expectedResponseType : "json",
                callback : {
                    fn : this._onTaskReceive,
                    scope : this,
                    args : cb
                }
            });
        },

        _onTaskReceive : function (res, cb) {
            this._data.tasksList = res.responseJSON.tasksList;
            this.loadSubModules([{
                        refpath : "taskManager",
                        classpath : "exercises.handson.todoctrl.TaskManager"
                    }], cb);
        },

        onSubModuleEvent : function (evt) {
            if (evt.name == "listUpdated" || evt.name == "listUpdateBegin") {
                this.$raiseEvent(evt.name);
            }
            if (evt.name == "taskAdded") {
                this.json.add(this._data.tasksList, evt.task);

            }
        },

        deleteTask : function (e, task) {
            var idx = this._data.tasksList.indexOf(task);
            this.json.removeAt(this._data.tasksList, idx);
        }
    }
});
