Aria.interfaceDefinition({
    $classpath : "exercises.handson.todoctrl.ITodoCtrl",
    $extends : "aria.templates.IModuleCtrl",
    $events : {
        "listUpdated" : "Raised when the list of task is updated after trying to add a new task.",
        "listUpdateBegin" : "Raised before connecting to the server to add a new task."
    },
    $interface : {

        deleteTask : {
            $type : "Function"
        }
    }
});
