Aria.interfaceDefinition({
    $classpath : "exercises.handson.todoctrl.ITaskManager",
    $extends : "aria.templates.IModuleCtrl",
    $events : {
        "listUpdated" : "Raised when the list of task is updated after trying to add a new task.",
        "listUpdateBegin" : "Raised before connecting to the server to add a new task.",
        "taskAdded" : {
            description : "Raised when the addition of a task is successful.",
            properties : {
                task : "task to add."
            }
        }
    },
    $interface : {

        addTask : {
            $type : "Function",
            $callbackParam : 1
        }

    }
});
