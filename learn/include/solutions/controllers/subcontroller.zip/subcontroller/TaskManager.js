Aria.classDefinition({
    $classpath : "exercises.handson.todoctrl.TaskManager",
    $extends : "aria.templates.ModuleCtrl",
    $implements : ["exercises.handson.todoctrl.ITaskManager"],
    $statics : {
        INVALID_NEW_TASK_LABEL : "The label for the new task is not valid. It should be have between 1 and 20 characters"
    },
    $prototype : {

        $publicInterfaceName : "exercises.handson.todoctrl.ITaskManager",

        init : function (args, cb) {
            this._data = {
                newTask : "",
                error : ""
            };
            this.$callback(cb);
        },

        addTask : function (e, cb) {
            this.$raiseEvent("listUpdateBegin");
            this.json.setValue(this._data, "error", "");
            var newTask = this._data.newTask;
            var valid = this._validateTaskLabel(newTask);
            if (valid) {
                aria.core.IO.asyncRequest({
                    url : "/myServer/addTask",
                    expectedResponseType : "json",
                    callback : {
                        fn : this._onTaskAdd,
                        scope : this,
                        args : cb
                    }
                });

            } else {
                this.json.setValue(this._data, "error", this.INVALID_NEW_TASK_LABEL);
                this.$raiseEvent("listUpdated");
                this.$callback(cb);
            }
        },

        _onTaskAdd : function (res, cb) {
            var response = res.responseJSON;
            if (response.error) {
                this.json.setValue(this._data, "error", response.msg);
            } else {
                this.$raiseEvent({
                    name : "taskAdded",
                    task : {
                        label : this._data.newTask,
                        done : false
                    }
                });
            }
            this.$raiseEvent("listUpdated");
            this.$callback(cb);
        },

        _validateTaskLabel : function (label) {
            var labelLength = label.length;
            return (labelLength > 0) && (labelLength <= 20);
        }

    }
});
