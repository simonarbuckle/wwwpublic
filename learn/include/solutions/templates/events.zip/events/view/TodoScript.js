Aria.tplScriptDefinition({
    $classpath : "exercises.handson.todo.view.TodoScript",
    $prototype : {

        markAsDone : function (evt, task) {
            task.done = !task.done;
            this.$refresh();
        },

        deleteTask : function (evt, index) {
            this.$json.splice(this.data.tasksList, index, 1);
            this.$refresh();
        }

    }
});
