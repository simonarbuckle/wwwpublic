Aria.tplScriptDefinition({
    $classpath : "exercises.handson.todo.view.TodoScript",
    $prototype : {

        deleteTask : function (evt, index) {
            this.$json.splice(this.data.tasksList, index, 1);
        },

        addTask : function () {
            this.$json.add(this.data.tasksList, {
                label : this.data.newTask,
                done : false
            });
        }
    }
});
