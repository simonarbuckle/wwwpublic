Aria.tplScriptDefinition({
    $classpath : "exercises.handson.todo.view.TodoScript",
    $prototype : {

        deleteTask : function (evt, index) {
            this.$json.splice(this.data.tasksList, index, 1);
        }
    }
});
