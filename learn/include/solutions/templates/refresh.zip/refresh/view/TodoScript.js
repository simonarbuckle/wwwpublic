Aria.tplScriptDefinition({
    $classpath : "exercises.handson.todo.view.TodoScript",
    $prototype : {

        markAsDone : function (evt, task) {
            task.done = !task.done;
            this.$refresh();
        }

    }
});
