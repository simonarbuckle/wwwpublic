Aria.tplScriptDefinition({
    $classpath : "exercises.handson.todo.view.TodoScript",
    $prototype : {

        markAsDone : function () {
            alert("click");
        }

    }
});
